/**
 * Сервис для управления подписками через членство в канале
 */

// Временное хранилище данных о статусе пользователей в канале
// В реальном приложении следует использовать базу данных
const userChannelStatus = {};

// ID закрытого канала для подписчиков
const PREMIUM_CHANNEL_ID = '-1002318892546';

/**
 * Декодирует Unicode-последовательности в читаемый текст
 * @param {string} text - Текст с возможными Unicode-последовательностями
 * @returns {string} - Декодированный текст
 */
function decodeUnicodeText(text) {
  if (typeof text !== 'string') {
    return text;
  }
  
  // Проверяем, содержит ли текст Unicode-последовательности
  if (!text.includes('u04')) {
    return text;
  }
  
  try {
    // Заменяем последовательности вида u04XX на соответствующие символы кириллицы
    let decodedText = '';
    let i = 0;
    
    while (i < text.length) {
      if (text[i] === 'u' && i + 5 <= text.length && /^[0-9a-fA-F]{4}$/.test(text.substring(i + 1, i + 5))) {
        // Извлекаем 4 символа после 'u' и преобразуем их в символ Unicode
        const codePoint = parseInt(text.substring(i + 1, i + 5), 16);
        decodedText += String.fromCharCode(codePoint);
        i += 5; // Пропускаем 'u' и 4 символа кода
      } else {
        decodedText += text[i];
        i++;
      }
    }
    
    return decodedText;
  } catch (error) {
    console.error('Ошибка при декодировании Unicode-последовательностей:', error);
    return text; // В случае ошибки возвращаем исходный текст
  }
}

/**
 * Отправляет сообщение пользователю с правильной кодировкой
 * @param {Object} bot - Экземпляр бота
 * @param {number} chatId - ID чата
 * @param {string} text - Текст сообщения
 * @param {Object} options - Дополнительные опции для сообщения
 */
async function sendMessage(bot, chatId, text, options = {}) {
  try {
    // Декодируем Unicode-последовательности в тексте
    const decodedText = decodeUnicodeText(text);
    
    // Если есть inline_keyboard в опциях, декодируем текст кнопок
    if (options.reply_markup && options.reply_markup.inline_keyboard) {
      options.reply_markup.inline_keyboard = options.reply_markup.inline_keyboard.map(row => {
        return row.map(button => {
          if (button.text) {
            button.text = decodeUnicodeText(button.text);
          }
          return button;
        });
      });
    }
    
    // Отправляем сообщение с декодированным текстом
    await bot.sendMessage(chatId, decodedText, options);
    
    // Для отладки
    if (text !== decodedText) {
      console.log('Текст был декодирован из Unicode-последовательностей');
    }
  } catch (error) {
    console.error('Ошибка при отправке сообщения:', error);
    
    // Пытаемся отправить исходный текст в случае ошибки
    try {
      await bot.sendMessage(chatId, text, options);
    } catch (secondError) {
      console.error('Не удалось отправить исходный текст:', secondError);
    }
  }
}

/**
 * Проверяет, является ли пользователь участником премиум-канала
 * @param {Object} bot - Экземпляр бота
 * @param {string} userId - ID пользователя
 * @returns {Promise<boolean>} - true, если пользователь является участником канала
 */
async function checkChannelMembership(bot, userId) {
  try {
    const chatMember = await bot.getChatMember(PREMIUM_CHANNEL_ID, userId);
    
    // Проверяем статус пользователя в канале
    // Возможные статусы: 'creator', 'administrator', 'member', 'restricted', 'left', 'kicked'
    const isChannelMember = ['creator', 'administrator', 'member', 'restricted'].includes(chatMember.status);
    
    // Обновляем статус в хранилище
    userChannelStatus[userId] = {
      isMember: isChannelMember,
      lastChecked: new Date()
    };
    
    return isChannelMember;
  } catch (error) {
    console.error('Ошибка при проверке членства в канале:', error);
    
    // Если произошла ошибка, возвращаем последний известный статус
    // или false, если статус неизвестен
    return userChannelStatus[userId]?.isMember || false;
  }
}

/**
 * Проверяет, имеет ли пользователь премиум-доступ
 * @param {Object} bot - Экземпляр бота
 * @param {string} userId - ID пользователя
 * @returns {Promise<boolean>} - true, если пользователь имеет премиум-доступ
 */
async function hasPremiumAccess(bot, userId) {
  // Если статус не проверялся в течение последних 30 минут, проверяем заново
  const lastChecked = userChannelStatus[userId]?.lastChecked;
  const thirtyMinutesAgo = new Date(Date.now() - 30 * 60 * 1000);
  
  if (!lastChecked || lastChecked < thirtyMinutesAgo) {
    return await checkChannelMembership(bot, userId);
  }
  
  // Возвращаем сохраненный статус
  return userChannelStatus[userId]?.isMember || false;
}

/**
 * Проверяет членство всех пользователей в канале
 * @param {Object} bot - Экземпляр бота
 * @returns {Promise<Object>} - Объект с результатами проверки
 */
async function checkAllUsersChannelMembership(bot) {
  const results = {
    checked: 0,
    leftChannel: []
  };
  
  for (const userId in userChannelStatus) {
    const previousStatus = userChannelStatus[userId].isMember;
    
    // Проверяем текущий статус
    const currentStatus = await checkChannelMembership(bot, userId);
    results.checked++;
    
    // Если пользователь вышел из канала
    if (previousStatus && !currentStatus) {
      results.leftChannel.push(userId);
    }
  }
  
  return results;
}

/**
 * Отправляет уведомление пользователю о деактивации премиум-функций
 * @param {Object} bot - Экземпляр бота
 * @param {string} userId - ID пользователя
 */
async function notifyPremiumDeactivation(bot, userId) {
  try {
    await sendMessage(
      bot,
      userId,
      `⚠️ Ваш премиум-доступ деактивирован, так как вы больше не являетесь участником канала подписчиков.

Чтобы восстановить доступ к премиум-функциям, пожалуйста, вернитесь в канал или оформите подписку.`,
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: 'Подписаться', url: 'https://t.me/+tocIp-n_c8FlNDJi' }]
          ]
        }
      }
    );
  } catch (error) {
    console.error('Ошибка при отправке уведомления о деактивации:', error);
  }
}

/**
 * Отправляет сообщение о необходимости подписки
 * @param {Object} bot - Экземпляр бота
 * @param {number} chatId - ID чата
 */
async function sendSubscriptionRequiredMessage(bot, chatId) {
  await sendMessage(
    bot,
    chatId,
    `⭐ Для доступа к этой функции требуется премиум-подписка.

Чтобы получить доступ, вступите в наш закрытый канал для подписчиков. В канале вы найдете инструкцию по оплате.

Стоимость подписки: $29 в месяц через сервис Трибут.`,
    {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'Перейти в канал для оплаты', url: 'https://t.me/+tocIp-n_c8FlNDJi' }],
          [{ text: 'Подробнее о преимуществах', callback_data: 'premium_benefits' }]
        ]
      }
    }
  );
}

/**
 * Отправляет информацию о преимуществах премиум-подписки
 * @param {Object} bot - Экземпляр бота
 * @param {Object} callbackQuery - Объект callback query
 */
async function sendPremiumBenefits(bot, callbackQuery) {
  const chatId = callbackQuery.message.chat.id;
  
  // Отвечаем на callback query
  await bot.answerCallbackQuery(callbackQuery.id);
  
  await sendMessage(
    bot,
    chatId,
    `✨ Преимущества премиум-подписки:

✅ Неограниченное количество запросов к боту
✅ Доступ ко всем категориям кейсов для подготовки к интервью
✅ Приоритетная обработка запросов
✅ Доступ к эксклюзивным материалам в закрытом канале
✅ Персональные консультации от экспертов

Стоимость: $29 в месяц. Инструкция по оплате находится в канале.`,
    {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'Перейти в канал для оплаты', url: 'https://t.me/+tocIp-n_c8FlNDJi' }]
        ]
      }
    }
  );
}

module.exports = {
  checkChannelMembership,
  hasPremiumAccess,
  checkAllUsersChannelMembership,
  notifyPremiumDeactivation,
  sendSubscriptionRequiredMessage,
  sendPremiumBenefits,
  sendMessage,
  decodeUnicodeText,
  PREMIUM_CHANNEL_ID
};
